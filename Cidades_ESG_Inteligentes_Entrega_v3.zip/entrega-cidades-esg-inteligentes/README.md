# Cidades ESG Inteligentes

**Disciplina:** DevOps | **Integrantes:** Alvaro Miranda, João Victor, Vitor Viana e Leonardo Sabbatini

API REST para registrar iniciativas de sustentabilidade de cidades, acompanhar o impacto estimado e classificar cada iniciativa nos pilares Ambiental, Social e Governança (ESG).

## Como executar localmente com Docker

1. Copie as variáveis de exemplo: `cp .env.example .env`.
2. Inicie o ambiente de homologação: `docker compose --env-file .env --profile staging up --build -d`.
3. Consulte a saúde: `curl http://localhost:8081/actuator/health`.
4. Consulte iniciativas: `curl http://localhost:8081/api/iniciativas`.
5. Para produção local, use: `docker compose --env-file .env --profile production up --build -d` e acesse a porta `8082`.
6. Finalize com `docker compose down -v`.

## Pipeline CI/CD

O GitHub Actions executa o workflow em `.github/workflows/ci-cd.yml`. Em cada `push` ou pull request para `main`, ele:

1. compila o projeto Maven e executa os testes;
2. constrói e sobe o ambiente **staging** com Docker Compose, banco PostgreSQL, rede e health check;
3. constrói e sobe o ambiente **production** isolado, após a conclusão do staging;
4. encerra e remove os containers ao fim de cada job, preservando o log como evidência da entrega automatizada.

O workflow usa runners hospedados pelo GitHub, portanto não requer VPS, chaves SSH ou secrets. Os ambientes são temporários: a execução é automatizada e verificável nos logs, mas não mantém uma URL pública após o fim do job. Opcionalmente, configure aprovação manual no Environment `production` em `Settings > Environments`.

## Containerização

O `Dockerfile` usa build multi-stage: Maven com JDK 21 gera o JAR e uma imagem JRE 21 enxuta o executa sem usuário root. O `docker-compose.yml` disponibiliza instâncias isoladas em staging e produção, cada uma com banco PostgreSQL, volume persistente, rede interna e variáveis de ambiente.

## Prints do funcionamento

As evidências reais de execução são produzidas no próprio GitHub Actions. Antes de enviar, inclua capturas de:

- aba Actions com as etapas `test`, `deploy-staging` e `deploy-production` concluídas;
- log do job staging com o retorno `UP` de `/actuator/health` na porta 8081;
- log do job production com o retorno `UP` de `/actuator/health` na porta 8082.

## Tecnologias utilizadas

- Java 21, Spring Boot 3.3, Spring Web, Spring Data JPA e Actuator
- JUnit 5 e Spring Boot Test
- PostgreSQL 16 e H2 (testes)
- Docker, Docker Compose e GitHub Actions
- GitHub Container Registry (GHCR)

## Endpoints principais

| Método | Rota | Finalidade |
| --- | --- | --- |
| GET | `/api/iniciativas` | Lista iniciativas ESG |
| POST | `/api/iniciativas` | Cria iniciativa |
| PATCH | `/api/iniciativas/{id}/status?status=EM_ANDAMENTO` | Atualiza status |
| GET | `/actuator/health` | Health check |

### Exemplo de criação

```json
{
  "titulo": "Telhados verdes em escolas",
  "cidade": "São Paulo",
  "pilar": "AMBIENTAL",
  "descricao": "Ampliação da cobertura vegetal em prédios públicos.",
  "impactoEstimado": 420
}
```

## Checklist de entrega

- [x] Projeto compactado em `.zip` com estrutura organizada
- [x] Dockerfile funcional
- [x] `docker-compose.yml` com aplicação, banco, volumes, variáveis e redes
- [x] Pipeline com build, testes e deploy staging/produção
- [x] README com instruções e roteiro de evidências
- [x] Documentação técnica em PDF
- [ ] Evidências reais do pipeline e dos ambientes anexadas após executar o workflow no GitHub
